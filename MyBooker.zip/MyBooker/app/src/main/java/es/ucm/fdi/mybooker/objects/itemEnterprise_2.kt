package es.ucm.fdi.mybooker.objects

data class itemEnterprise_2(val name: String, val email: String, val category: String, val location: String, val cp: String)