package es.ucm.fdi.mybooker.objects

data class itemReserve(val hora: String, val nombre: String, val personas: Int)