package es.ucm.fdi.mybooker.objects

data class itemEnterprise(val enterpriseImg: String, val enterpriseName: String, val enterpriseAddress: String, val enterpriseCategory: String)